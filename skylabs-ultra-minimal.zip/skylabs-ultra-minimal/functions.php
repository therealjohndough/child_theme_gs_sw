<?php
/**
 * Ultra Minimal Child Theme - No style enqueuing
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Absolutely nothing else - let WordPress handle everything automatically