<?php
// Empty functions.php for companion theme approach